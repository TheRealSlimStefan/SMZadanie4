//
//  SceneDelegate.h
//  Zadanie 4
//
//  Created by student on 15/11/2021.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

