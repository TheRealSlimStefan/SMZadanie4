//
//  ViewController.h
//  Zadanie 4
//
//  Created by student on 15/11/2021.
//

#import <UIKit/UIKit.h>

@interface SecondViewController : UIViewController <CLLocationManaagerDelegate>
@property (weak, nonatomic) IBOutlet UILabel *latitudeLabel;
@property (weak, nonatomic) IBOutlet UILabel *longtiudeLabel;
@property (weak, nonatomic) IBOutlet UILabel *addressLabel;

@property (weak, nonatomic) IBOutlet UITextField *latitudeText;
@property (weak, nonatomic) IBOutlet UITextField *longtiudeText;
@property (weak, nonatomic) IBOutlet UITextView *addressText;
@property (weak, nonatomic) IBOutlet UIButton *currentLocationButton;

-(IBAction)getCurrentLocation:(id)sender;

@end

@interface ViewController : UIViewController

@property (weak, nonatomic) IBOutlet UILabel *gestureLabel;

-(IBAction)tapGesture:(UITapGestureRecognizer *) sender;
-(IBAction)pinchGesture:(UIPinchGestureRecognizer *) sender;
-(IBAction)swipeGesture:(UISwipeGestureRecognizer *) sender;
-(IBAction)longPressGesture:(UILongPressGestureRecognizer *) sender;

@end

